<?php
/**
 * Created by PhpStorm.
 * User: Leticia
 * Date: 24/10/2017
 * Time: 19:58
 */

class funcionario
{
    public $nome;
    public $departamento;
    public $salario;
    public $data;
    public $RG;

    public  function recebeAumento($aumento){
        $this->salario = $aumento;
    }
    public function calculaGanhoAnual(){
        $ganho = $this->salario * 12;
        echo "o ganho anual é $ganho";
        print_r($ganho);

        
    }
}



